<?php
$conn = new mysqli(getenv("DB_HOST"), getenv("DB_USER"), getenv("DB_PASS"), getenv("DB_NAME"));
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);
$result = $conn->query("SELECT * FROM schedule ORDER BY day_of_week, start_time");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>課程表</title>
    <style>
        body {
            text-align: center;
            font-size: 20px;
        }
        table {
            margin: auto;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px 16px;
            border: 1px solid #888;
        }
        a.button {
            display: inline-block;
            margin: 10px;
            padding: 10px 20px;
            background: #007BFF;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        a.button:hover {
            background: #0056b3;
        }
        form {
            display: inline;
        }
    </style>
</head>
<body>
    <h1>課程表</h1>

    <a class="button" href="edit_schedule.php">新增課程</a>

    <table>
        <tr>
            <th>課程名稱</th>
            <th>星期</th>
            <th>開始時間</th>
            <th>結束時間</th>
            <th>操作</th>
        </tr>
        <?php while($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($row['course_name']) ?></td>
            <td><?= htmlspecialchars($row['day_of_week']) ?></td>
            <td><?= htmlspecialchars($row['start_time']) ?></td>
            <td><?= htmlspecialchars($row['end_time']) ?></td>
            <td>
                <form method="POST" action="delete_schedule.php" onsubmit="return confirm('確定要刪除這門課嗎？');">
                    <input type="hidden" name="id" value="<?= $row['id'] ?>">
                    <button type="submit">刪除</button>
                </form>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
