<?php
$conn = new mysqli(getenv("DB_HOST"), getenv("DB_USER"), getenv("DB_PASS"), getenv("DB_NAME"));
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $course = $_POST["course"];
    $day = $_POST["day"];
    $start = $_POST["start"];
    $end = $_POST["end"];
    $conn->query("INSERT INTO schedule (course_name, day_of_week, start_time, end_time) VALUES ('$course', '$day', '$start', '$end')");
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <title>新增課程</title>
    <style>
        body {
            font-family: sans-serif;
            text-align: center;
            padding-top: 50px;
            background-color: #f9f9f9;
        }
        h1 {
            font-size: 32px;
        }
        form {
            display: inline-block;
            text-align: left;
            font-size: 20px;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
        }
        label, input {
            display: block;
            margin: 10px 0;
            width: 100%;
        }
        input[type="submit"] {
            margin-top: 20px;
            font-size: 20px;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 6px;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        a {
            display: inline-block;
            margin-top: 20px;
            font-size: 18px;
            color: #333;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <h1>新增課程</h1>
    <form method="post">
        <label>課程名稱：<input type="text" name="course" required></label>
        <label>星期：<input type="text" name="day" required></label>
        <label>開始時間：<input type="time" name="start" required></label>
        <label>結束時間：<input type="time" name="end" required></label>
        <input type="submit" value="儲存課程">
    </form>
    <a href="index.php">← 返回首頁</a>
</body>
</html>
